package test;

import org.junit.Test;

public class OtherTest extends Base {

    @Test public void mytest() {
        run();
    }

}
